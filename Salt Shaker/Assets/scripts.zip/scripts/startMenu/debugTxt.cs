﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class debugTxt : MonoBehaviour {

	void Start () {
		DontDestroyOnLoad(gameObject);
	}
}
